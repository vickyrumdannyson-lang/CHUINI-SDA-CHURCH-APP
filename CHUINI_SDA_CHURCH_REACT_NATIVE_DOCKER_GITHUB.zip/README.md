# CHUINI SDA CHURCH — React Native Android

Native Android app built with React Native + Expo prebuild. This is an Android application, not a web app.

## Includes
- Official Chuini SDA Church logo asset as supplied.
- Kiswahili and English interface language selection, persisted locally.
- Dashboard, weekly program, announcements, Bible/resources preview, more/settings/about.
- Local on-device persistence for language, announcements and events.
- Docker Android build environment.
- GitHub Actions workflow that generates an installable release APK artifact.

## Build APK with GitHub
1. Upload/push the contents of this folder to the existing GitHub repository `vickyrumdannyson-lang/CHUINI-SDA-CHURCH` on branch `main`.
2. Open repository → Actions → `CHUINI SDA CHURCH Android APK`.
3. Wait for the workflow to finish successfully.
4. Open the completed workflow run → Artifacts → download `CHUINI-SDA-CHURCH-APK`.
5. Extract the ZIP and install the APK on Android. On first install Android may ask permission to install from that source.

## Build using Docker
Run `docker compose build` then `docker compose run --rm chuini-android-builder`.
The generated APK is under `android/app/build/outputs/apk/release/` in the container; for local Docker builds, adjust the compose volume/output mapping as needed.

## Production limitations — important
This is a native Android app foundation and CI APK build pipeline, not yet the complete production church platform. The current announcement/event/admin content is stored on one phone only. There is no cloud authentication, shared database, server-side role enforcement, remote media storage, push notification service, or full Bible/hymnbook text. Those require a church-owned Firebase/Supabase project, approved credentials, server security rules and licensed content. The app intentionally does not invent church leaders, official phone numbers, service hours or unapproved content. Do not treat the current local content editor as secure Super Admin.
