import React from 'react';
import { StatusBar } from 'expo-status-bar';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { Ionicons } from '@expo/vector-icons';
import { AuthProvider } from './src/auth';
import { colors } from './src/theme';
import Home from './src/screens/Home';
import More from './src/screens/More';
import About from './src/screens/About';
import Contact from './src/screens/Contact';
import Prayers from './src/screens/Prayers';
import Account from './src/screens/Account';
import Admin from './src/screens/Admin';
import * as L from './src/screens/Lists';

const Tab = createBottomTabNavigator();
const Stack = createNativeStackNavigator();
const icons: Record<string, any> = { Nyumbani: 'home', Ratiba: 'time', Matangazo: 'megaphone', Idara: 'people', Zaidi: 'menu' };
const header = { headerStyle: { backgroundColor: colors.navy }, headerTintColor: '#fff', headerTitleStyle: { fontWeight: '700' as const } };

function Tabs() {
  return (
    <Tab.Navigator screenOptions={({ route }) => ({ ...header, tabBarActiveTintColor: colors.navy, tabBarInactiveTintColor: colors.muted, tabBarLabelStyle: { fontWeight: '600', fontSize: 11 }, tabBarIcon: ({ color, size }) => <Ionicons name={icons[route.name]} size={size} color={color} /> })}>
      <Tab.Screen name="Nyumbani" component={Home} options={{ headerShown: false }} />
      <Tab.Screen name="Ratiba" component={L.Ratiba} options={{ title: 'Ratiba za Kanisa' }} />
      <Tab.Screen name="Matangazo" component={L.Matangazo} />
      <Tab.Screen name="Idara" component={L.Idara} options={{ title: 'Idara za Kanisa' }} />
      <Tab.Screen name="Zaidi" component={More} />
    </Tab.Navigator>
  );
}

const pages: [string, React.ComponentType<any>, string][] = [
  ['Kuhusu', About, 'Kuhusu Kanisa'], ['Mawasiliano', Contact, 'Mawasiliano'], ['Matukio', L.Matukio, 'Matukio'], ['Mahubiri', L.Mahubiri, 'Mahubiri'],
  ['Masomo', L.Masomo, 'Masomo ya Biblia'], ['Makala', L.Makala, 'Tafakari na Makala'], ['Nyimbo', L.Nyimbo, 'Nyimbo za Kristo'], ['Kwaya', L.Kwaya, 'Kwaya na Muziki'],
  ['Picha', L.Picha, 'Picha na Video'], ['Vitabu', L.Vitabu, 'Duka la Vitabu'], ['Maombi', Prayers, 'Maombi na Ushuhuda'], ['Akaunti', Account, 'Akaunti Yangu'], ['Usimamizi', Admin, 'Usimamizi'],
];

export default function App() {
  return (
    <AuthProvider>
      <NavigationContainer>
        <StatusBar style="light" />
        <Stack.Navigator screenOptions={header}>
          <Stack.Screen name="Tabs" component={Tabs} options={{ headerShown: false }} />
          {pages.map(([n, c, t]) => <Stack.Screen key={n} name={n} component={c} options={{ title: t }} />)}
        </Stack.Navigator>
      </NavigationContainer>
    </AuthProvider>
  );
}
