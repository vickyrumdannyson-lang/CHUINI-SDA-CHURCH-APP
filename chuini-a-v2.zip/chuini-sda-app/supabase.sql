-- CHUINI SDA CHURCH APP: schema + usalama (RLS). Bandika kwenye Supabase > SQL Editor > Run.
create table profiles (id uuid primary key references auth.users on delete cascade, full_name text,
  role text not null default 'member' check (role in ('super_admin','admin','leader','editor','member')), created_at timestamptz default now());
create table settings (key text primary key, value text);
create table announcements (id bigint generated always as identity primary key, title text not null, body text, category text, pinned boolean default false, expires_at timestamptz, url text, created_at timestamptz default now());
create table events (id bigint generated always as identity primary key, title text not null, kind text not null default 'event' check (kind in ('event','weekly')), weekday int check (weekday between 0 and 6), time_text text, start_at timestamptz, venue text, department text, description text, created_at timestamptz default now());
create table departments (id bigint generated always as identity primary key, name text not null, description text, leaders text, activities text, url text, created_at timestamptz default now());
create table resources (id bigint generated always as identity primary key, kind text not null, title text not null, author text, body text, url text, created_at timestamptz default now());
create table gallery (id bigint generated always as identity primary key, title text not null, category text, url text, created_at timestamptz default now());
create table books (id bigint generated always as identity primary key, title text not null, author text, description text, price text, available boolean default true, url text, created_at timestamptz default now());
create table prayers (id bigint generated always as identity primary key, user_id uuid references auth.users default auth.uid(), name text, body text not null, is_public boolean default false, approved boolean default false, created_at timestamptz default now());

create function public.my_role() returns text language sql stable security definer set search_path=public as $$ select role from profiles where id=auth.uid() $$;
create function public.is_staff() returns boolean language sql stable security definer set search_path=public as $$ select coalesce(public.my_role() in ('super_admin','admin','leader','editor'),false) $$;
create function public.is_leader() returns boolean language sql stable security definer set search_path=public as $$ select coalesce(public.my_role() in ('super_admin','admin','leader'),false) $$;
create function public.is_admin() returns boolean language sql stable security definer set search_path=public as $$ select coalesce(public.my_role() in ('super_admin','admin'),false) $$;

create function public.handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$
begin insert into profiles(id, full_name) values (new.id, new.raw_user_meta_data->>'full_name'); return new; end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();

do $$ declare t text; begin
  foreach t in array array['announcements','events','departments','resources','gallery','books'] loop
    execute format('alter table %I enable row level security', t);
    execute format('create policy "soma" on %I for select using (true)', t);
    execute format('create policy "andika" on %I for all using (public.is_staff()) with check (public.is_staff())', t);
  end loop;
end $$;

alter table settings enable row level security;
create policy "soma" on settings for select using (true);
create policy "andika" on settings for all using (public.is_admin()) with check (public.is_admin());

alter table profiles enable row level security;
create policy "soma" on profiles for select using (id = auth.uid() or public.is_admin());
create policy "badilisha" on profiles for update using (public.is_admin()) with check (public.is_admin());

alter table prayers enable row level security;
create policy "soma" on prayers for select using (public.is_leader() or user_id = auth.uid() or (is_public and approved));
create policy "tuma" on prayers for insert with check (auth.uid() is not null and user_id = auth.uid());
create policy "idhinisha" on prayers for update using (public.is_leader());
create policy "futa" on prayers for delete using (public.is_leader() or user_id = auth.uid());

insert into settings(key,value) values ('mission','Kuunganisha kanisa, kuimarisha imani na kuendeleza Injili.') on conflict do nothing;

-- BAADA ya kujisajili kwenye app, jifanye Msimamizi Mkuu (badilisha barua pepe yako):
-- update profiles set role='super_admin' where id = (select id from auth.users where email='BARUA_PEPE_YAKO');
