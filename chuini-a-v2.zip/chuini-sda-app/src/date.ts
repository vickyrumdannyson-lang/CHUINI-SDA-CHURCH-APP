export const days = ['Jumapili', 'Jumatatu', 'Jumanne', 'Jumatano', 'Alhamisi', 'Ijumaa', 'Jumamosi'];
const months = ['Januari', 'Februari', 'Machi', 'Aprili', 'Mei', 'Juni', 'Julai', 'Agosti', 'Septemba', 'Oktoba', 'Novemba', 'Desemba'];
const p = (n: number) => String(n).padStart(2, '0');
export const dayName = (i: number) => days[i] ?? '';
export const shortDate = (iso?: string) => { if (!iso) return ''; const d = new Date(iso); return `${d.getDate()} ${months[d.getMonth()]} ${d.getFullYear()}`; };
export const fullDate = (iso?: string) => { if (!iso) return ''; const d = new Date(iso); return `${days[d.getDay()]}, ${shortDate(iso)} · ${p(d.getHours())}:${p(d.getMinutes())}`; };
export const todayLabel = () => { const d = new Date(); return `${days[d.getDay()]}, ${d.getDate()} ${months[d.getMonth()]} ${d.getFullYear()}`; };
export const toInput = (iso: string) => { const d = new Date(iso); return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`; };
export const fromInput = (s: string) => { const d = new Date(s.trim().replace(' ', 'T')); return isNaN(+d) ? null : d.toISOString(); };
