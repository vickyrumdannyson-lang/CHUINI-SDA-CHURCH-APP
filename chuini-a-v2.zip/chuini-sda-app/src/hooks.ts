import { useCallback, useState } from 'react';
import { useFocusEffect } from '@react-navigation/native';
import { configured, supabase } from './supabase';

export function useSettings() {
  const [s, setS] = useState<Record<string, string>>({});
  useFocusEffect(useCallback(() => {
    if (!configured) return;
    supabase.from('settings').select('*').then(({ data }) => {
      const m: Record<string, string> = {};
      (data || []).forEach((r: any) => { if (r.value) m[r.key] = r.value; });
      setS(m);
    });
  }, []));
  return s;
}
