import React from 'react';
import { Pressable, ScrollView, StyleSheet, Text, TextInput, TextInputProps, View } from 'react-native';
import { colors } from './theme';

export const Screen = ({ children }: { children: React.ReactNode }) => (
  <ScrollView style={{ flex: 1, backgroundColor: colors.grey }} contentContainerStyle={{ padding: 16, gap: 12 }} keyboardShouldPersistTaps="handled">{children}</ScrollView>
);
export const Card = ({ title, sub, extra, children }: { title?: string; sub?: string; extra?: string; children?: React.ReactNode }) => (
  <View style={s.card}>
    {title ? <Text style={s.title}>{title}</Text> : null}
    {sub ? <Text style={s.sub}>{sub}</Text> : null}
    {extra ? <Text style={s.body}>{extra}</Text> : null}
    {children}
  </View>
);
export const Heading = ({ text }: { text: string }) => <Text style={s.heading}>{text}</Text>;
export const Empty = ({ text }: { text: string }) => <View style={s.empty}><Text style={{ color: colors.muted, textAlign: 'center' }}>{text}</Text></View>;
export const Btn = ({ label, onPress, alt, danger }: { label: string; onPress: () => void; alt?: boolean; danger?: boolean }) => (
  <Pressable onPress={onPress} style={[s.btn, alt && s.alt, danger && { backgroundColor: colors.danger }]}>
    <Text style={[s.btnText, alt && { color: colors.navy }]}>{label}</Text>
  </Pressable>
);
export const Input = (p: TextInputProps) => <TextInput placeholderTextColor={colors.muted} {...p} style={[s.input, p.multiline && { minHeight: 90, textAlignVertical: 'top' }, p.style]} />;

const s = StyleSheet.create({
  card: { backgroundColor: colors.white, borderRadius: 14, padding: 14, gap: 4, borderWidth: 1, borderColor: colors.border, shadowColor: '#000', shadowOpacity: 0.05, shadowRadius: 6, shadowOffset: { width: 0, height: 2 }, elevation: 1 },
  title: { fontSize: 16, fontWeight: '700', color: colors.navy },
  sub: { fontSize: 13, color: colors.primary, fontWeight: '600' },
  body: { fontSize: 14, color: colors.text, lineHeight: 20, marginTop: 2 },
  heading: { fontSize: 18, fontWeight: '800', color: colors.navy, marginTop: 6 },
  empty: { padding: 24, borderRadius: 14, backgroundColor: colors.white, borderWidth: 1, borderColor: colors.border, borderStyle: 'dashed' },
  btn: { backgroundColor: colors.navy, paddingVertical: 12, paddingHorizontal: 16, borderRadius: 10, alignItems: 'center', marginTop: 6 },
  alt: { backgroundColor: colors.white, borderWidth: 1.5, borderColor: colors.navy },
  btnText: { color: '#fff', fontWeight: '700' },
  input: { backgroundColor: colors.white, borderWidth: 1, borderColor: colors.border, borderRadius: 10, padding: 12, color: colors.text, fontSize: 15 },
});
