// Weka thamani kutoka Supabase (Project Settings > API). Anon key ni ya umma kwa makusudi; usalama uko kwenye RLS.
export const SUPABASE_URL = '';
export const SUPABASE_ANON_KEY = '';
