import React from 'react';
import { Image, View } from 'react-native';
import { Card, Empty, Screen } from '../components';
import { useSettings } from '../hooks';

export default function About() {
  const st = useSettings();
  const sec = (title: string, k: string) => (st[k] ? <Card title={title} extra={st[k]} /> : <Card title={title}><Empty text="Itawekwa na msimamizi." /></Card>);
  return (
    <Screen>
      <View style={{ alignItems: 'center' }}><Image source={require('../../assets/logo.png')} style={{ width: 180, height: 180 }} resizeMode="contain" /></View>
      <Card title="CHUINI SDA CHURCH ZANZIBAR" sub="Kanisa la Waadventista Wasabato" extra={'Mtaa wa Chuini\nZanzibar Field Station (ZFS)\nSouthern Tanzania Union Mission (STUM)\nTanzania'} />
      <Card title="Dhamira" extra={st.mission || 'Kuunganisha kanisa, kuimarisha imani na kuendeleza Injili.'} />
      {sec('Maono', 'vision')}
      {sec('Maadili ya Msingi', 'values')}
      {sec('Historia ya Kanisa', 'about_history')}
      {sec('Uongozi', 'leadership')}
    </Screen>
  );
}
