import React, { useCallback, useState } from 'react';
import { Alert, Text } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { Btn, Card, Empty, Input, Screen } from '../components';
import { supabase } from '../supabase';
import { useAuth } from '../auth';
import { settingKeys } from '../cfg';
import { colors } from '../theme';

export default function Admin() {
  const { admin } = useAuth();
  const [v, setV] = useState<Record<string, string>>({});
  useFocusEffect(useCallback(() => {
    supabase.from('settings').select('*').then(({ data }) => {
      const m: Record<string, string> = {};
      (data || []).forEach((r: any) => { m[r.key] = r.value || ''; });
      setV(m);
    });
  }, []));
  if (!admin) return <Screen><Empty text="Ukurasa huu ni wa wasimamizi pekee." /></Screen>;
  const save = async () => {
    const rows = settingKeys.map(([key]) => ({ key, value: (v[key] || '').trim() || null }));
    const { error } = await supabase.from('settings').upsert(rows);
    Alert.alert(error ? 'Hitilafu' : 'Imehifadhiwa', error ? error.message : 'Mipangilio imesasishwa.');
  };
  return (
    <Screen>
      <Card title="Mipangilio ya Kanisa" extra="Badilisha taarifa za nyumbani, kuhusu kanisa na mawasiliano. Ratiba, matangazo, idara na maudhui mengine hubadilishwa moja kwa moja kwenye kurasa zake kwa kubonyeza + Ongeza / Hariri." />
      {settingKeys.map(([k, label]) => (
        <Card key={k}>
          <Text style={{ color: colors.navy, fontWeight: '600' }}>{label}</Text>
          <Input value={v[k] || ''} onChangeText={(x) => setV((p) => ({ ...p, [k]: x }))} multiline={['mission', 'vision', 'values', 'about_history', 'leadership', 'verse_text', 'welcome'].includes(k)} autoCapitalize="none" />
        </Card>
      ))}
      <Btn label="Hifadhi Mipangilio" onPress={save} />
    </Screen>
  );
}
