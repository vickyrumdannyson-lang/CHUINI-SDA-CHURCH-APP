import React from 'react';
import { Linking } from 'react-native';
import { Btn, Card, Empty, Screen } from '../components';
import { useSettings } from '../hooks';

export default function Contact() {
  const st = useSettings();
  const any = st.phone || st.whatsapp || st.email || st.address || st.maps_url || st.youtube_url;
  return (
    <Screen>
      {st.address ? <Card title="Anuani" extra={st.address} /> : null}
      {!any ? <Empty text="Taarifa za mawasiliano zitawekwa na msimamizi." /> : null}
      {st.phone ? <Btn label={`Piga simu: ${st.phone}`} onPress={() => Linking.openURL(`tel:${st.phone}`)} /> : null}
      {st.whatsapp ? <Btn label="WhatsApp" onPress={() => Linking.openURL(`https://wa.me/${st.whatsapp}`)} /> : null}
      {st.email ? <Btn label={`Barua pepe: ${st.email}`} onPress={() => Linking.openURL(`mailto:${st.email}`)} alt /> : null}
      {st.maps_url ? <Btn label="Fungua Ramani" onPress={() => Linking.openURL(st.maps_url)} alt /> : null}
      {st.youtube_url ? <Btn label="YouTube ya Kanisa" onPress={() => Linking.openURL(st.youtube_url)} alt /> : null}
    </Screen>
  );
}
