import React, { useCallback, useState } from 'react';
import { Alert, Switch, Text, View } from 'react-native';
import { useFocusEffect, useNavigation } from '@react-navigation/native';
import { Btn, Card, Empty, Heading, Input, Screen } from '../components';
import { configured, supabase } from '../supabase';
import { useAuth } from '../auth';
import { shortDate } from '../date';
import { colors } from '../theme';

export default function Prayers() {
  const { session, leader } = useAuth();
  const nav = useNavigation<any>();
  const [rows, setRows] = useState<any[]>([]);
  const [body, setBody] = useState('');
  const [name, setName] = useState('');
  const [pub, setPub] = useState(false);

  const load = useCallback(async () => {
    if (!configured) return;
    const { data } = await supabase.from('prayers').select('*').order('created_at', { ascending: false });
    setRows(data || []);
  }, []);
  useFocusEffect(useCallback(() => { load(); }, [load]));

  const send = async () => {
    if (!body.trim()) return Alert.alert('Kosa', 'Andika ombi lako.');
    const { error } = await supabase.from('prayers').insert({ body: body.trim(), name: name.trim() || null, is_public: pub });
    if (error) return Alert.alert('Hitilafu', error.message);
    setBody(''); setName('');
    Alert.alert('Asante', pub ? 'Ombi lako litaonekana baada ya kuidhinishwa na viongozi.' : 'Ombi lako la siri limewafikia viongozi.');
    load();
  };
  const approve = async (id: number) => { await supabase.from('prayers').update({ approved: true }).eq('id', id); load(); };
  const remove = async (id: number) => { await supabase.from('prayers').delete().eq('id', id); load(); };

  return (
    <Screen>
      {session ? (
        <Card title="Tuma Ombi au Ushuhuda">
          <Input value={body} onChangeText={setBody} multiline placeholder="Andika hapa…" />
          <Input value={name} onChangeText={setName} placeholder="Jina (si lazima)" />
          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 4 }}>
            <Text style={{ color: colors.navy, flex: 1 }}>{pub ? 'Ombi la wazi (litaidhinishwa)' : 'Ombi la siri (viongozi pekee)'}</Text>
            <Switch value={pub} onValueChange={setPub} trackColor={{ true: colors.primary }} />
          </View>
          <Btn label="Tuma" onPress={send} />
        </Card>
      ) : (
        <Card title="Ingia ili kutuma ombi"><Btn label="Ingia / Jisajili" onPress={() => nav.navigate('Akaunti')} /></Card>
      )}
      <Heading text="Maombi" />
      {rows.length === 0 ? <Empty text="Hakuna maombi ya kuonyesha." /> : rows.map((r) => (
        <Card key={r.id} title={r.name || 'Mwanachama'} sub={`${shortDate(r.created_at)} · ${r.is_public ? (r.approved ? 'Wazi' : 'Linasubiri idhini') : 'Siri'}`} extra={r.body}>
          {leader && r.is_public && !r.approved ? <Btn label="Idhinisha" onPress={() => approve(r.id)} /> : null}
          {leader ? <Btn label="Futa" onPress={() => remove(r.id)} danger /> : null}
        </Card>
      ))}
    </Screen>
  );
}
