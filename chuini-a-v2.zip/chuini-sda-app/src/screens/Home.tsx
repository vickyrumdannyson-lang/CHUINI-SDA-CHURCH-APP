import React, { useCallback, useState } from 'react';
import { Image, Linking, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useFocusEffect, useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { Card, Empty, Heading } from '../components';
import { configured, supabase } from '../supabase';
import { useSettings } from '../hooks';
import { fullDate, todayLabel } from '../date';
import { colors } from '../theme';

const shortcuts: { label: string; icon: any; to: string }[] = [
  { label: 'Ratiba', icon: 'time', to: 'Ratiba' }, { label: 'Matangazo', icon: 'megaphone', to: 'Matangazo' },
  { label: 'Biblia', icon: 'book', to: 'BIBLIA' }, { label: 'Nyimbo za Kristo', icon: 'musical-notes', to: 'Nyimbo' },
  { label: 'Masomo ya Biblia', icon: 'school', to: 'Masomo' }, { label: 'Idara', icon: 'people', to: 'Idara' },
  { label: 'Kwaya', icon: 'mic', to: 'Kwaya' }, { label: 'Matukio', icon: 'calendar', to: 'Matukio' },
  { label: 'Maombi', icon: 'heart', to: 'Maombi' }, { label: 'Mawasiliano', icon: 'call', to: 'Mawasiliano' },
];

export default function Home() {
  const insets = useSafeAreaInsets();
  const nav = useNavigation<any>();
  const st = useSettings();
  const [d, setD] = useState<{ ann: any[]; ev: any[]; today: any[] }>({ ann: [], ev: [], today: [] });

  useFocusEffect(useCallback(() => {
    if (!configured) return;
    (async () => {
      const now = new Date().toISOString();
      const [a, e, w] = await Promise.all([
        supabase.from('announcements').select('*').or(`expires_at.is.null,expires_at.gte.${now}`).order('pinned', { ascending: false }).order('created_at', { ascending: false }).limit(3),
        supabase.from('events').select('*').eq('kind', 'event').gte('start_at', now).order('start_at').limit(3),
        supabase.from('events').select('*').eq('kind', 'weekly').eq('weekday', new Date().getDay()),
      ]);
      setD({ ann: a.data || [], ev: e.data || [], today: w.data || [] });
    })();
  }, []));

  const left = (6 - new Date().getDay() + 7) % 7;
  const go = (to: string) => (to === 'BIBLIA' ? Linking.openURL('https://www.bible.com/') : nav.navigate(to));

  return (
    <ScrollView style={{ flex: 1, backgroundColor: colors.grey }} contentContainerStyle={{ paddingBottom: 28 }}>
      <View style={[s.hero, { paddingTop: insets.top + 16 }]}>
        <View style={s.logoWrap}><Image source={require('../../assets/logo.png')} style={s.logo} resizeMode="contain" /></View>
        <Text style={s.name}>CHUINI SDA CHURCH</Text>
        <Text style={s.sub}>ZANZIBAR</Text>
        <Text style={s.date}>{todayLabel()}</Text>
        <Text style={s.welcome}>{st.welcome || 'Karibu! Sabato njema na ubarikiwe.'}</Text>
      </View>
      <View style={s.body}>
        {!configured ? <Empty text="Programu bado haijaunganishwa na seva (Supabase). Taarifa zitaonekana baada ya msimamizi kukamilisha usanidi." /> : null}
        <View style={s.sabbath}>
          <Ionicons name="sunny" size={26} color={colors.navy} />
          <Text style={s.sabbathText}>{left === 0 ? 'Leo ni Sabato — Sabato njema!' : `Siku ${left} hadi Sabato`}</Text>
        </View>

        <Heading text="Njia za Haraka" />
        <View style={s.grid}>
          {shortcuts.map((a) => (
            <Pressable key={a.label} style={s.tile} onPress={() => go(a.to)}>
              <Ionicons name={a.icon} size={24} color={colors.navy} />
              <Text style={s.tileText}>{a.label}</Text>
            </Pressable>
          ))}
        </View>

        <Heading text="Shughuli za Leo" />
        {d.today.length ? d.today.map((r) => <Card key={r.id} title={r.title} sub={[r.time_text, r.venue].filter(Boolean).join(' · ')} />) : <Empty text="Hakuna shughuli zilizowekwa kwa leo." />}

        <Heading text="Matangazo ya Karibuni" />
        {d.ann.length ? d.ann.map((r) => <Card key={r.id} title={(r.pinned ? '📌 ' : '') + r.title} sub={r.category} extra={r.body} />) : <Empty text="Hakuna matangazo kwa sasa." />}

        <Heading text="Matukio Yajayo" />
        {d.ev.length ? d.ev.map((r) => <Card key={r.id} title={r.title} sub={fullDate(r.start_at)} extra={r.venue ? `📍 ${r.venue}` : undefined} />) : <Empty text="Hakuna matukio yajayo." />}

        <Heading text="Mstari wa Biblia" />
        {st.verse_text ? <Card title={`“${st.verse_text}”`} sub={st.verse_ref} /> : <Empty text="Mstari utawekwa na msimamizi." />}
      </View>
    </ScrollView>
  );
}

const s = StyleSheet.create({
  hero: { backgroundColor: colors.navy, alignItems: 'center', paddingHorizontal: 20, paddingBottom: 24, borderBottomLeftRadius: 28, borderBottomRightRadius: 28 },
  logoWrap: { width: 128, height: 128, borderRadius: 64, backgroundColor: '#F9F9F9', padding: 6, borderWidth: 3, borderColor: colors.primary },
  logo: { width: '100%', height: '100%', borderRadius: 58 },
  name: { color: '#fff', fontSize: 22, fontWeight: '800', marginTop: 12 },
  sub: { color: colors.primary, fontSize: 13, fontWeight: '700', letterSpacing: 3 },
  date: { color: '#BFD9F2', marginTop: 8, fontSize: 13 },
  welcome: { color: '#fff', marginTop: 8, textAlign: 'center', lineHeight: 20 },
  body: { padding: 16, gap: 10 },
  sabbath: { backgroundColor: colors.sky, borderRadius: 14, padding: 14, flexDirection: 'row', alignItems: 'center', gap: 12, borderWidth: 1, borderColor: colors.primary },
  sabbathText: { color: colors.navy, fontWeight: '700', fontSize: 16 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  tile: { width: '31.5%', backgroundColor: '#fff', borderRadius: 12, paddingVertical: 12, paddingHorizontal: 4, alignItems: 'center', gap: 6, borderWidth: 1, borderColor: colors.border },
  tileText: { fontSize: 11, fontWeight: '700', color: colors.navy, textAlign: 'center' },
});
