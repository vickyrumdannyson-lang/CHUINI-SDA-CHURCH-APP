import React from 'react';
import { Linking, Pressable, Text, View } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { Screen } from '../components';
import { useAuth } from '../auth';
import { colors } from '../theme';

const items: [string, string, any][] = [
  ['Kuhusu', 'Kuhusu Kanisa', 'information-circle'], ['Mawasiliano', 'Mawasiliano na Ramani', 'call'], ['Matukio', 'Matukio', 'calendar'],
  ['Mahubiri', 'Mahubiri', 'mic'], ['Masomo', 'Masomo ya Biblia', 'school'], ['Makala', 'Tafakari na Makala', 'document-text'],
  ['Nyimbo', 'Nyimbo za Kristo', 'musical-notes'], ['Kwaya', 'Kwaya na Muziki', 'musical-note'], ['Picha', 'Picha na Video', 'images'],
  ['Vitabu', 'Duka la Vitabu', 'library'], ['Maombi', 'Maombi na Ushuhuda', 'heart'], ['BIBLIA', 'Biblia (tovuti)', 'book'], ['Akaunti', 'Akaunti Yangu', 'person-circle'],
];

export default function More() {
  const nav = useNavigation<any>();
  const { admin } = useAuth();
  const all = admin ? [...items, ['Usimamizi', 'Usimamizi (Msimamizi)', 'settings'] as [string, string, any]] : items;
  return (
    <Screen>
      {all.map(([to, label, icon]) => (
        <Pressable key={to} onPress={() => (to === 'BIBLIA' ? Linking.openURL('https://www.bible.com/') : nav.navigate(to))} style={{ backgroundColor: '#fff', borderRadius: 12, padding: 14, flexDirection: 'row', alignItems: 'center', gap: 12, borderWidth: 1, borderColor: colors.border }}>
          <Ionicons name={icon} size={22} color={colors.primary} />
          <Text style={{ flex: 1, color: colors.navy, fontWeight: '600', fontSize: 15 }}>{label}</Text>
          <Ionicons name="chevron-forward" size={18} color={colors.muted} />
        </Pressable>
      ))}
      <View style={{ alignItems: 'center', marginTop: 8 }}>
        <Text style={{ color: colors.muted, fontSize: 12, textAlign: 'center' }}>CHUINI SDA CHURCH ZANZIBAR{'\n'}Zanzibar Field Station (ZFS) · Southern Tanzania Union Mission (STUM)</Text>
      </View>
    </Screen>
  );
}
