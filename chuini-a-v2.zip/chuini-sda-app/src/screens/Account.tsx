import React, { useState } from 'react';
import { Alert } from 'react-native';
import { Btn, Card, Empty, Input, Screen } from '../components';
import { configured, supabase } from '../supabase';
import { useAuth } from '../auth';

const roles: Record<string, string> = { super_admin: 'Msimamizi Mkuu', admin: 'Msimamizi wa Kanisa', leader: 'Kiongozi wa Idara', editor: 'Mhariri / Timu ya Habari', member: 'Mwanachama' };

export default function Account() {
  const { session, name, role } = useAuth();
  const [mode, setMode] = useState<'in' | 'up' | 'reset'>('in');
  const [email, setEmail] = useState('');
  const [pw, setPw] = useState('');
  const [full, setFull] = useState('');

  if (!configured) return <Screen><Empty text="Programu bado haijaunganishwa na seva." /></Screen>;
  if (session) {
    return (
      <Screen>
        <Card title={name} sub={roles[role] || 'Mwanachama'} extra={session.user.email} />
        <Btn label="Toka" onPress={() => supabase.auth.signOut()} alt />
      </Screen>
    );
  }
  const go = async () => {
    if (!email.trim()) return Alert.alert('Kosa', 'Weka barua pepe.');
    if (mode === 'reset') {
      const { error } = await supabase.auth.resetPasswordForEmail(email.trim());
      return Alert.alert(error ? 'Hitilafu' : 'Imetumwa', error ? error.message : 'Angalia barua pepe yako kuweka nenosiri jipya.');
    }
    if (pw.length < 6) return Alert.alert('Kosa', 'Nenosiri liwe na herufi 6 au zaidi.');
    if (mode === 'up') {
      if (!full.trim()) return Alert.alert('Kosa', 'Weka jina lako kamili.');
      const { data, error } = await supabase.auth.signUp({ email: email.trim(), password: pw, options: { data: { full_name: full.trim() } } });
      if (error) return Alert.alert('Hitilafu', error.message);
      if (!data.session) Alert.alert('Karibu', 'Angalia barua pepe yako kuthibitisha akaunti, kisha ingia.');
    } else {
      const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password: pw });
      if (error) Alert.alert('Hitilafu', error.message);
    }
  };
  return (
    <Screen>
      <Card title={mode === 'in' ? 'Ingia' : mode === 'up' ? 'Jisajili' : 'Weka Nenosiri Jipya'}>
        {mode === 'up' ? <Input value={full} onChangeText={setFull} placeholder="Jina kamili" /> : null}
        <Input value={email} onChangeText={setEmail} placeholder="Barua pepe" autoCapitalize="none" keyboardType="email-address" />
        {mode !== 'reset' ? <Input value={pw} onChangeText={setPw} placeholder="Nenosiri" secureTextEntry /> : null}
        <Btn label={mode === 'in' ? 'Ingia' : mode === 'up' ? 'Jisajili' : 'Tuma kiungo'} onPress={go} />
      </Card>
      {mode !== 'in' ? <Btn label="Nina akaunti — Ingia" onPress={() => setMode('in')} alt /> : <Btn label="Jisajili akaunti mpya" onPress={() => setMode('up')} alt />}
      {mode !== 'reset' ? <Btn label="Nimesahau nenosiri" onPress={() => setMode('reset')} alt /> : null}
    </Screen>
  );
}
