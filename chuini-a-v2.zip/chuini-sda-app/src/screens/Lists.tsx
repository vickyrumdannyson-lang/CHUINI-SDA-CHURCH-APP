import React from 'react';
import { Linking, View } from 'react-native';
import CrudList, { Cfg } from '../crud';
import { Btn } from '../components';
import { useSettings } from '../hooks';
import * as C from '../cfg';

const mk = (cfg: Cfg) => () => <CrudList cfg={cfg} />;
export const Ratiba = mk(C.weekly);
export const Matangazo = mk(C.announcements);
export const Matukio = mk(C.events);
export const Idara = mk(C.departments);
export const Picha = mk(C.gallery);
export const Kwaya = mk(C.resource('kwaya', 'Taarifa za kwaya bado hazijawekwa.'));
export const Nyimbo = mk(C.resource('nyimbo', 'Nyimbo bado hazijawekwa. Msimamizi anaweza kuongeza nyimbo zenye ruhusa ya matumizi.'));
export const Masomo = mk(C.resource('masomo', 'Masomo ya Biblia bado hayajawekwa.'));
export const Mahubiri = mk(C.resource('mahubiri', 'Mahubiri bado hayajawekwa.'));
export const Makala = mk(C.resource('makala', 'Makala na tafakari bado hazijawekwa.'));

export function Vitabu() {
  const st = useSettings();
  return (
    <View style={{ flex: 1 }}>
      <CrudList cfg={C.books} />
      {st.whatsapp ? <View style={{ padding: 12 }}><Btn label="Agiza kupitia WhatsApp" onPress={() => Linking.openURL(`https://wa.me/${st.whatsapp}`)} /></View> : null}
    </View>
  );
}
