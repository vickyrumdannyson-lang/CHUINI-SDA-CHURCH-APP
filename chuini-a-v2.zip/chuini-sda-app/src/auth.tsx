import React, { createContext, useContext, useEffect, useState } from 'react';
import { Session } from '@supabase/supabase-js';
import { configured, supabase } from './supabase';

type Ctx = { session: Session | null; role: string; name: string; staff: boolean; leader: boolean; admin: boolean };
const AuthCtx = createContext<Ctx>({ session: null, role: 'public', name: '', staff: false, leader: false, admin: false });
export const useAuth = () => useContext(AuthCtx);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [prof, setProf] = useState({ role: 'public', name: '' });

  const load = async (s: Session | null) => {
    if (!s) return setProf({ role: 'public', name: '' });
    const { data } = await supabase.from('profiles').select('role,full_name').eq('id', s.user.id).maybeSingle();
    setProf({ role: data?.role || 'member', name: data?.full_name || s.user.email || '' });
  };

  useEffect(() => {
    if (!configured) return;
    supabase.auth.getSession().then(({ data }) => { setSession(data.session); load(data.session); });
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => { setSession(s); load(s); });
    return () => sub.subscription.unsubscribe();
  }, []);

  const r = prof.role;
  const value = { session, role: r, name: prof.name, staff: ['super_admin', 'admin', 'leader', 'editor'].includes(r), leader: ['super_admin', 'admin', 'leader'].includes(r), admin: ['super_admin', 'admin'].includes(r) };
  return <AuthCtx.Provider value={value}>{children}</AuthCtx.Provider>;
}
