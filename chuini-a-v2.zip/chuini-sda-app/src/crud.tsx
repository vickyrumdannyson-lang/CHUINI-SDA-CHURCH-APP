import React, { useCallback, useState } from 'react';
import { Alert, Linking, Modal, Pressable, ScrollView, Switch, Text, View } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { configured, supabase } from './supabase';
import { useAuth } from './auth';
import { Btn, Card, Empty, Heading, Input, Screen } from './components';
import { colors } from './theme';
import { fromInput, toInput } from './date';

export type F = { key: string; label: string; type?: 'text' | 'area' | 'bool' | 'int' | 'dt' | 'select'; options?: string[]; idx?: boolean; req?: boolean };
export type Cfg = {
  table: string; fields: F[]; title: (r: any) => string; sub?: (r: any) => string; extra?: (r: any) => string;
  eq?: Record<string, any>; order?: string; asc?: boolean; sort?: (a: any, b: any) => number;
  group?: (r: any) => string; visible?: (r: any) => boolean; search?: boolean; empty?: string;
};

function Form({ cfg, init, onClose }: { cfg: Cfg; init: any; onClose: (saved: boolean) => void }) {
  const [v, setV] = useState<any>(() => {
    const o = { ...init };
    cfg.fields.forEach((f) => { if (f.type === 'dt' && o[f.key]) o[f.key] = toInput(o[f.key]); });
    return o;
  });
  const set = (k: string, x: any) => setV((p: any) => ({ ...p, [k]: x }));

  const save = async () => {
    const p: any = { ...(cfg.eq || {}) };
    for (const f of cfg.fields) {
      let x = v[f.key];
      if (f.type === 'bool') { p[f.key] = !!x; continue; }
      if (f.req && (x === undefined || x === null || x === '')) return Alert.alert('Kosa', `${f.label} inahitajika`);
      if (x === '' || x === undefined) x = null;
      if (x !== null && f.type === 'int') x = Number(x);
      if (x !== null && f.type === 'dt') { x = fromInput(String(x)); if (!x) return Alert.alert('Kosa', `${f.label}: andika kama 2026-12-05 09:00`); }
      p[f.key] = x;
    }
    const { error } = init.id ? await supabase.from(cfg.table).update(p).eq('id', init.id) : await supabase.from(cfg.table).insert(p);
    if (error) return Alert.alert('Hitilafu', error.message);
    onClose(true);
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.grey }}>
      <ScrollView contentContainerStyle={{ padding: 16, gap: 8, paddingTop: 48 }} keyboardShouldPersistTaps="handled">
        <Heading text={init.id ? 'Hariri' : 'Ongeza'} />
        {cfg.fields.map((f) => (
          <View key={f.key} style={{ gap: 4 }}>
            <Text style={{ color: colors.navy, fontWeight: '600' }}>{f.label}{f.req ? ' *' : ''}</Text>
            {f.type === 'bool' ? (
              <Switch value={!!v[f.key]} onValueChange={(x) => set(f.key, x)} trackColor={{ true: colors.primary }} />
            ) : f.type === 'select' ? (
              <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6 }}>
                {f.options!.map((o, i) => {
                  const val = f.idx ? i : o;
                  const on = v[f.key] === val;
                  return (
                    <Pressable key={o} onPress={() => set(f.key, val)} style={{ paddingVertical: 8, paddingHorizontal: 12, borderRadius: 18, backgroundColor: on ? colors.navy : colors.white, borderWidth: 1, borderColor: colors.border }}>
                      <Text style={{ color: on ? '#fff' : colors.navy }}>{o}</Text>
                    </Pressable>
                  );
                })}
              </View>
            ) : (
              <Input value={v[f.key] == null ? '' : String(v[f.key])} onChangeText={(x) => set(f.key, x)} multiline={f.type === 'area'} keyboardType={f.type === 'int' ? 'numeric' : 'default'} placeholder={f.type === 'dt' ? '2026-12-05 09:00' : undefined} />
            )}
          </View>
        ))}
        <Btn label="Hifadhi" onPress={save} />
        <Btn label="Ghairi" onPress={() => onClose(false)} alt />
      </ScrollView>
    </View>
  );
}

export default function CrudList({ cfg }: { cfg: Cfg }) {
  const { staff } = useAuth();
  const [rows, setRows] = useState<any[] | null>(null);
  const [form, setForm] = useState<any | null>(null);
  const [q, setQ] = useState('');

  const load = useCallback(async () => {
    if (!configured) return setRows([]);
    let query: any = supabase.from(cfg.table).select('*');
    Object.entries(cfg.eq || {}).forEach(([k, v]) => { query = query.eq(k, v); });
    const { data, error } = await query.order(cfg.order || 'created_at', { ascending: !!cfg.asc });
    if (error) Alert.alert('Hitilafu', error.message);
    setRows(data || []);
  }, [cfg]);
  useFocusEffect(useCallback(() => { load(); }, [load]));

  const del = (r: any) => Alert.alert('Futa?', cfg.title(r), [
    { text: 'Hapana' },
    { text: 'Futa', style: 'destructive', onPress: async () => { await supabase.from(cfg.table).delete().eq('id', r.id); load(); } },
  ]);

  let list = (rows || []).filter((r) => staff || !cfg.visible || cfg.visible(r));
  if (q) list = list.filter((r) => `${cfg.title(r)} ${cfg.extra?.(r) || ''}`.toLowerCase().includes(q.toLowerCase()));
  if (cfg.sort) list = [...list].sort(cfg.sort);
  let last = '';

  return (
    <Screen>
      {!configured ? <Empty text="Programu bado haijaunganishwa na seva. Msimamizi afuate maelekezo ya Supabase." /> : null}
      {cfg.search ? <Input value={q} onChangeText={setQ} placeholder="Tafuta kwa jina au namba…" /> : null}
      {staff && configured ? <Btn label="+ Ongeza" onPress={() => setForm({ ...(cfg.eq || {}) })} /> : null}
      {rows === null && configured ? <Text style={{ color: colors.muted }}>Inapakia…</Text> : null}
      {rows !== null && list.length === 0 && configured ? <Empty text={cfg.empty || 'Hakuna taarifa iliyowekwa bado.'} /> : null}
      {list.map((r) => {
        const g = cfg.group?.(r);
        const head = g && g !== last ? <Heading key={'h' + g} text={g} /> : null;
        if (g) last = g;
        return (
          <React.Fragment key={r.id}>
            {head}
            <Card title={cfg.title(r)} sub={cfg.sub?.(r)} extra={cfg.extra?.(r)}>
              {r.url ? <Btn label="Fungua kiungo" onPress={() => Linking.openURL(r.url)} alt /> : null}
              {staff ? (
                <View style={{ flexDirection: 'row', gap: 8 }}>
                  <View style={{ flex: 1 }}><Btn label="Hariri" onPress={() => setForm(r)} alt /></View>
                  <View style={{ flex: 1 }}><Btn label="Futa" onPress={() => del(r)} danger /></View>
                </View>
              ) : null}
            </Card>
          </React.Fragment>
        );
      })}
      <Modal visible={!!form} animationType="slide" onRequestClose={() => setForm(null)}>
        {form ? <Form cfg={cfg} init={form} onClose={(saved) => { setForm(null); if (saved) load(); }} /> : null}
      </Modal>
    </Screen>
  );
}
