export const colors = { primary: '#4FA3E0', navy: '#0B2A5B', sky: '#E6F3FC', white: '#FFFFFF', grey: '#F1F3F5', text: '#0B2A5B', muted: '#5B6B80', border: '#D9E2EC', danger: '#C0392B' };
