import { Cfg } from './crud';
import { days, dayName, fullDate, shortDate } from './date';

const cats = ['Rasmi', 'Idara', 'Msiba', 'Harusi', 'Ibada Maalum', 'Maendeleo ya Kanisa', 'Konferensi / ZFS', 'Mengine'];
const galCats = ['Ibada ya Sabato', 'Matukio ya Kanisa', 'Kwaya', 'Vijana', 'Uinjilisti', 'Ubatizo', 'Huduma kwa Jamii', 'Mengine'];
const lk = { key: 'url', label: 'Kiungo (picha / PDF / YouTube / tovuti)' };

export const announcements: Cfg = {
  table: 'announcements', empty: 'Hakuna matangazo kwa sasa.',
  fields: [{ key: 'title', label: 'Kichwa', req: true }, { key: 'category', label: 'Aina', type: 'select', options: cats }, { key: 'body', label: 'Maelezo', type: 'area' }, { key: 'pinned', label: 'Bandika juu', type: 'bool' }, { key: 'expires_at', label: 'Mwisho wa kuonyeshwa', type: 'dt' }, lk],
  title: (r) => (r.pinned ? '📌 ' : '') + r.title, sub: (r) => [r.category, shortDate(r.created_at)].filter(Boolean).join(' · '), extra: (r) => r.body,
  sort: (a, b) => Number(b.pinned) - Number(a.pinned) || b.created_at.localeCompare(a.created_at),
  visible: (r) => !r.expires_at || new Date(r.expires_at) >= new Date(),
};
export const weekly: Cfg = {
  table: 'events', eq: { kind: 'weekly' }, empty: 'Ratiba bado haijawekwa na msimamizi.',
  fields: [{ key: 'title', label: 'Shughuli', req: true }, { key: 'weekday', label: 'Siku', type: 'select', options: days, idx: true, req: true }, { key: 'time_text', label: 'Muda' }, { key: 'venue', label: 'Mahali' }, { key: 'department', label: 'Idara husika' }, { key: 'description', label: 'Maelezo', type: 'area' }],
  title: (r) => r.title, sub: (r) => [r.time_text, r.venue].filter(Boolean).join(' · '), extra: (r) => [r.department && `Idara: ${r.department}`, r.description].filter(Boolean).join('\n'),
  group: (r) => dayName(r.weekday), sort: (a, b) => a.weekday - b.weekday || (a.time_text || '').localeCompare(b.time_text || ''),
};
export const events: Cfg = {
  table: 'events', eq: { kind: 'event' }, order: 'start_at', asc: true, empty: 'Hakuna matukio yajayo.',
  fields: [{ key: 'title', label: 'Tukio', req: true }, { key: 'start_at', label: 'Tarehe na saa (2026-12-05 09:00)', type: 'dt', req: true }, { key: 'venue', label: 'Mahali' }, { key: 'department', label: 'Idara husika' }, { key: 'description', label: 'Maelezo', type: 'area' }],
  title: (r) => r.title, sub: (r) => fullDate(r.start_at), extra: (r) => [r.venue && `📍 ${r.venue}`, r.department && `Idara: ${r.department}`, r.description].filter(Boolean).join('\n'),
  visible: (r) => new Date(r.start_at).getTime() >= Date.now() - 86400000,
};
export const departments: Cfg = {
  table: 'departments', order: 'name', asc: true, empty: 'Idara bado hazijawekwa.',
  fields: [{ key: 'name', label: 'Jina la idara', req: true }, { key: 'description', label: 'Maelezo', type: 'area' }, { key: 'leaders', label: 'Viongozi' }, { key: 'activities', label: 'Shughuli', type: 'area' }, lk],
  title: (r) => r.name, sub: (r) => (r.leaders ? `Viongozi: ${r.leaders}` : ''), extra: (r) => [r.description, r.activities && `Shughuli: ${r.activities}`].filter(Boolean).join('\n\n'),
};
export const resource = (kind: string, empty: string): Cfg => ({
  table: 'resources', eq: { kind }, search: true, empty,
  fields: [{ key: 'title', label: 'Kichwa / Namba na jina', req: true }, { key: 'author', label: 'Mhubiri / Mwandishi / Kwaya' }, { key: 'body', label: 'Maelezo au maandishi', type: 'area' }, lk],
  title: (r) => r.title, sub: (r) => r.author, extra: (r) => r.body,
});
export const gallery: Cfg = {
  table: 'gallery', empty: 'Picha na video bado hazijawekwa.',
  fields: [{ key: 'title', label: 'Kichwa', req: true }, { key: 'category', label: 'Kundi', type: 'select', options: galCats }, { key: 'url', label: 'Kiungo cha picha au YouTube', req: true }],
  title: (r) => r.title, sub: (r) => r.category,
};
export const books: Cfg = {
  table: 'books', empty: 'Vitabu bado havijawekwa.',
  fields: [{ key: 'title', label: 'Jina la kitabu', req: true }, { key: 'author', label: 'Mwandishi' }, { key: 'description', label: 'Maelezo', type: 'area' }, { key: 'price', label: 'Bei' }, { key: 'available', label: 'Kinapatikana', type: 'bool' }, { key: 'url', label: 'Kiungo cha picha ya jalada' }],
  title: (r) => r.title, sub: (r) => [r.author, r.price].filter(Boolean).join(' · '), extra: (r) => [r.description, r.available ? 'Kinapatikana' : 'Hakipatikani kwa sasa'].filter(Boolean).join('\n'),
};
export const settingKeys: [string, string][] = [
  ['welcome', 'Ujumbe wa kukaribisha'], ['verse_text', 'Mstari wa Biblia (maandishi)'], ['verse_ref', 'Mstari wa Biblia (rejea)'],
  ['mission', 'Dhamira'], ['vision', 'Maono'], ['values', 'Maadili ya Msingi'], ['about_history', 'Historia ya Kanisa'], ['leadership', 'Uongozi'],
  ['phone', 'Simu (mf. +255...)'], ['whatsapp', 'WhatsApp (mf. 255...)'], ['email', 'Barua pepe'], ['address', 'Anwani'], ['maps_url', 'Kiungo cha Ramani'], ['youtube_url', 'Kiungo cha YouTube ya kanisa'],
];
