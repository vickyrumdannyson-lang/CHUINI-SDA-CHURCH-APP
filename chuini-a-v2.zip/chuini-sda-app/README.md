# CHUINI SDA CHURCH ZANZIBAR — App ya Android

React Native (Expo) + Supabase (database, usajili, usalama wa majukumu).

## Usanidi wa Supabase (mara moja)
1. supabase.com → New project.
2. SQL Editor → bandika `supabase.sql` → Run.
3. Project Settings → API → nakili **Project URL** na **anon public key** → weka kwenye `src/config.ts`.
4. Jisajili kwenye app, kisha endesha mstari wa mwisho wa `supabase.sql` (ukiwa na barua pepe yako) ili uwe Msimamizi Mkuu.

## Majukumu
super_admin, admin (wasimamizi), leader (kiongozi: maudhui + maombi), editor (maudhui), member, mgeni.
Wasimamizi hubadilisha maudhui moja kwa moja kwenye kila ukurasa (+ Ongeza / Hariri / Futa) na mipangilio ya kanisa kwenye Zaidi → Usimamizi.

## APK
Weka zip kwenye GitHub; workflow ya Actions hujenga `chuini-sda.apk` (angalia Artifacts).
